package com.fiap.tcd6dvp.netflix.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.fiap.tcd6dvp.netflix.entity.Suporte;

@Repository
public interface SuporteRepository extends JpaRepository<Suporte, String> {

	Suporte findById(Long id);

}

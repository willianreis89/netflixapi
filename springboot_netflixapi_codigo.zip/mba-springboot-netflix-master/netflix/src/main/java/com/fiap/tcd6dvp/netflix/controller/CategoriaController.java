package com.fiap.tcd6dvp.netflix.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fiap.tcd6dvp.netflix.entity.Categoria;
import com.fiap.tcd6dvp.netflix.repository.CategoriaRepository;

@RestController
@RequestMapping(value = "/")
public class CategoriaController {

	@Autowired
	private CategoriaRepository categoriaRepository;

	@GetMapping(value={"categoria","categorias","filme/categoria","filmes/categoria","filme/maisvistos","filmes/maisvistos"})
	public List<Categoria> getAllCategoria() {
		return categoriaRepository.findAll();
	}

	@GetMapping(value={"categoria/{id}","categorias/{id}"})
	public List<Categoria> getFindOne(@PathVariable(name = "id") Long id) {
		return categoriaRepository.findById(id);
	}
	
}

package com.fiap.tcd6dvp.netflix.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.fiap.tcd6dvp.netflix.entity.Categoria;

@Repository
public interface CategoriaRepository extends JpaRepository<Categoria, String> {
	
	List<Categoria> findById(Long id);

}

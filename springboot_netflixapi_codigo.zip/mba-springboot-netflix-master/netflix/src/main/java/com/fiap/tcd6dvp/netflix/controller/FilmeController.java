package com.fiap.tcd6dvp.netflix.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fiap.tcd6dvp.netflix.repository.CategoriaRepository;
import com.fiap.tcd6dvp.netflix.entity.Categoria;
import com.fiap.tcd6dvp.netflix.entity.Filme;
import com.fiap.tcd6dvp.netflix.rabbitmq.CustomMessage;
import com.fiap.tcd6dvp.netflix.rabbitmq.MQConfig;
import com.fiap.tcd6dvp.netflix.repository.FilmeRepository;
import com.fiap.tcd6dvp.netflix.service.CacheService;
import com.fiap.tcd6dvp.netflix.redis.Cache;

@RestController
@RequestMapping(value = "/")
public class FilmeController {
	
	int count = 0;
	Long categoryParsed, idParsed;
	
	@Autowired
	private RabbitTemplate template;
	@Autowired
	private FilmeRepository filmeRepository;
	@Autowired
    private CacheService cacheService;
	@Autowired
	private CategoriaRepository categoriaRepository;
	
	@GetMapping(value={"filme","filmes"})
	public List<Filme> getAllFilme() {
		return filmeRepository.findAll();
	}

	@GetMapping(value = { "filme/{id}", "filmes/{id}" })
	public Filme getFindOne(@PathVariable(name = "id") Long id) {
		Filme filme = filmeRepository.findById(id);

		CustomMessage message = new CustomMessage();
		message.setMessageId(UUID.randomUUID().toString());
		message.setMessageDate(new Date());
		message.setMessage(filme.getId());
		template.convertAndSend(MQConfig.EXCHANGE_LISTENER, MQConfig.ROUTING_KEY, message); // Alterar MQConfig.EXCHANGE ou EXCHANGE_LISTENER fila que publica para cada microserviço

		if (cacheService.fetchUserById(id) != null) {
			count = cacheService.fetchUserById(id).getVisto();
			count += 1;
		} else {
			count = 1;
		};

		Cache cache = new Cache();
		cache.setId(filme.getId());
		cache.setFilme(filme.getName());
		cache.setCategoria(filme.getCategoryName().getName());
		cache.setVisto(count);
		cacheService.saveUser(cache);
		return filme;
	}

	@GetMapping(value={"filme/categoria/{categoryId}","filmes/categoria/{categoryId}"})
	public List<Filme> getFilmeByCategoria(@PathVariable(name = "categoryId") String categoryId) {

		List<Filme> resultFilm = filmeRepository.findAll();
		List<Filme> filmes = new ArrayList<Filme>();
	

		try {
			categoryParsed = Long.parseLong(categoryId);
		   	for (int i = 0; i < resultFilm.size(); i++) {
				if (resultFilm.get(i).getCategoryName().getId() == categoryParsed) {
					filmes.add(resultFilm.get(i));
				}
			}
	    } catch (NumberFormatException nfe) {
	    	for (int i = 0; i < resultFilm.size(); i++) {
				if (resultFilm.get(i).getCategoryName().getName().equalsIgnoreCase(categoryId)) {
					filmes.add(resultFilm.get(i));
				}
			}
	    }
		return filmes;
	}
	
	@GetMapping(value={"filme/pesquisar/{name}","filmes/pesquisar/{name}"})
	public List<Filme> getLikeName(@PathVariable(name = "name") String name) {

		List<Filme> filme = filmeRepository.findByNameLikeIgnoreCase("%" + name + "%");
		return filme;
	}

	@GetMapping(value={"filme/assistido","filmes/assistido"})
	public List<Filme> getFilmeView() {
		return filmeRepository.findByAssistido(true);
	}

	@GetMapping(value={"filme/assistido/{categoryId}","filmes/assistido/{categoryId}"})
	public List<Filme> getFilmeViewCategoria(@PathVariable(name = "categoryId") Long categoryId) {

		List<Filme> resultFilm = filmeRepository.findByAssistido(true);
		List<Filme> filmes = new ArrayList<Filme>();

		for (int i = 0; i < resultFilm.size(); i++) {

			if (resultFilm.get(i).getCategoryName().getId() == categoryId) {
				filmes.add(resultFilm.get(i));
			}
		}
		return filmes;
	}
	
	@GetMapping(value={"filme/maisvistos/{categoryId}","filmes/maisvistos/{categoryId}"})
	public List<Cache> getFindOneCategoria(@PathVariable(name = "categoryId") String categoryId) {
		
        List<Cache> resultCache = cacheService.fetchAllFilme();
		List<Cache> caches = new ArrayList<Cache>();

		try {
			categoryParsed = Long.parseLong(categoryId);
			int categoryParsedInt = categoryParsed.intValue();
			categoryParsedInt -= 1;
	    	List<Categoria> categorias = categoriaRepository.findAll();
		   	for (int i = 0; i < resultCache.size(); i++) {
		   		if (resultCache.get(i).getCategoria().equalsIgnoreCase(categorias.get(categoryParsedInt).getName())) {
					caches.add(resultCache.get(i));
			}
		  }
	    } catch (NumberFormatException nfe) {
	    	for (int i = 0; i < resultCache.size(); i++) {
				if (resultCache.get(i).getCategoria().equalsIgnoreCase(categoryId)) {
					caches.add(resultCache.get(i));
				}
			}
	    }
		return caches;
	}

	@PutMapping("filme/gostei/{id}")
	public ResponseEntity<String> setLiked(@PathVariable(name = "id") Long id) {

		Filme filme = filmeRepository.findById(id);
		filme.setLiked(true);

		filmeRepository.save(filme);
		
		boolean result = filmeRepository.save(filme).isLiked();
        if(result)
            return ResponseEntity.ok("Você gostou do filme "+ "'"+filme.getName()+"'" +" :-)");
        else
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
	}
	

	@PutMapping(value={"filme/assistido/{id}","filmes/assistido/{id}"})
	public ResponseEntity<String> setView(@PathVariable(name = "id") Long id) {

		Filme filme = filmeRepository.findById(id);
		filme.setView(true);
		filme.setFuture(false);

		filmeRepository.save(filme);

		boolean result = filmeRepository.save(filme).isAssistido();
        if(result)
            return ResponseEntity.ok("Filme "+ "'"+filme.getName()+"'" +" marcado como já assistido");
        else
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
	}
	
	@PutMapping(value={"filme/assistirdepois/{id}","filmes/assistirdepois/{id}"})
	public ResponseEntity<String> setFuture(@PathVariable(name = "id") Long id) {

		Filme filme = filmeRepository.findById(id);
		filme.setFuture(true);

		filmeRepository.save(filme);
		
		boolean result = filmeRepository.save(filme).isAssistirDepois();
        if(result)
            return ResponseEntity.ok("Filme "+ "'"+filme.getName()+"'" +" marcado para assistir mais tarde");
        else
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
	}
}
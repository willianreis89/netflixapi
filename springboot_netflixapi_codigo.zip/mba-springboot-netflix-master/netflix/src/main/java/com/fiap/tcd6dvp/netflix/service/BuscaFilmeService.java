package com.fiap.tcd6dvp.netflix.service;

import org.springframework.stereotype.Service;

import com.fiap.tcd6dvp.netflix.entity.Filme;
import com.fiap.tcd6dvp.netflix.utils.RandomUtils;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixProperty;

@Service
public class BuscaFilmeService {

//	public Filme getFilme (int filmeId) {
//		return new Filme(filmeId);
//	}
	
	@HystrixCommand(fallbackMethod = "getFilmeFallBack")
	public Filme getFilmeInfo(int id) {
		Filme filme = null;
		
		if (RandomUtils.random50PercentError() == 1) {
			throw new RuntimeException();
		} else {
			filme = new Filme();
		}
		
		return filme;
	}
	
	@HystrixCommand(fallbackMethod = "getGeneroCircuitBreak", commandProperties = {
			@HystrixProperty(name = "execution.isolation.thread.timeoutInMilliseconds", value = "200") })
	public Filme getFilme (int filmeId) {
		
		if (RandomUtils.random50PercentError() == 1) {
			RandomUtils.randomSleep();
		}
		
		return new Filme();
	}

	private int getGeneroCircuitBreak() {
		return -1;
	}
	
	private String getFilmeFallBack() {
		return "No information available about film";
	}
	
}

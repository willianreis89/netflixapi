package com.fiap.tcd6dvp.netflix.service;

import com.fiap.tcd6dvp.netflix.redis.Cache;
import com.fiap.tcd6dvp.netflix.repository.CacheDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CacheServiceImpl implements CacheService {

    @Autowired
    private CacheDao cacheDao;

    @Override
    public boolean saveUser(Cache user) {
        return cacheDao.saveUser(user);
    }

    @Override
    public List<Cache> fetchAllFilme() {
        return cacheDao.fetchAllUser();
    }

    @Override
    public Cache fetchUserById(Long id) {
        return cacheDao.fetchUserById(id);
    }

    @Override
    public boolean deleteUser(Long id) {
        return cacheDao.deleteUser(id);
    }

    @Override
    public boolean updateUser(Long id, Cache user) {
        return cacheDao.updateUser(id,user);
    }

}

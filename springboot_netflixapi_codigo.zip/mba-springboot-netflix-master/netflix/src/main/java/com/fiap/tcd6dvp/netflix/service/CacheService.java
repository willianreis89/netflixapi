package com.fiap.tcd6dvp.netflix.service;


import java.util.List;
import com.fiap.tcd6dvp.netflix.redis.Cache;

public interface CacheService {

    boolean saveUser(Cache user);

    List<Cache> fetchAllFilme();

    Cache fetchUserById(Long id);
    
    boolean deleteUser(Long id);

    boolean updateUser(Long id, Cache user);
}

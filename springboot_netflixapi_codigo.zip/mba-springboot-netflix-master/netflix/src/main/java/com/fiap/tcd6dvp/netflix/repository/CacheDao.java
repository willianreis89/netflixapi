package com.fiap.tcd6dvp.netflix.repository;

import com.fiap.tcd6dvp.netflix.redis.Cache;

import java.util.List;

public interface CacheDao {
    boolean saveUser(Cache user);

    List<Cache> fetchAllUser();

    Cache fetchUserById(Long id);

    boolean deleteUser(Long id);

    boolean updateUser(Long id, Cache user);
}

package com.fiap.tcd6dvp.netflix.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fiap.tcd6dvp.netflix.entity.Suporte;
import com.fiap.tcd6dvp.netflix.repository.SuporteRepository;

@RestController
@RequestMapping(value = "/")
public class SuporteController {

	@Autowired
	private SuporteRepository suporteRepository;

	@GetMapping("/suporte")
	public List<Suporte> getAllSuporte() {
		return suporteRepository.findAll();
	}

	@GetMapping("/suporte/{id}")
	public Suporte getFindOne(@PathVariable(name = "id") Long id) {
		return suporteRepository.findById(id);
	}

	@PostMapping("/suporte")
	public Suporte createSuporte(@Valid @RequestBody Suporte suporte) {
		return suporteRepository.save(suporte);
	}

}
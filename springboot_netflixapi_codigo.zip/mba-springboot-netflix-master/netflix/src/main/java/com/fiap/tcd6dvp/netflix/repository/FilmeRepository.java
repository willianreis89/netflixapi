package com.fiap.tcd6dvp.netflix.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.fiap.tcd6dvp.netflix.entity.Filme;

@Repository
public interface FilmeRepository extends JpaRepository<Filme, String> {
	
	Filme findById(Long id);
	List<Filme> findByNameLikeIgnoreCase(String name);
	List<Filme> findByAssistido(boolean assistido);

}

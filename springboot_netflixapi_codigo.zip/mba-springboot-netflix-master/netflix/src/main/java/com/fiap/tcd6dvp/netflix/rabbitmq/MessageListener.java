package com.fiap.tcd6dvp.netflix.rabbitmq;

import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.fiap.tcd6dvp.netflix.entity.Filme;
import com.fiap.tcd6dvp.netflix.repository.FilmeRepository;
import com.fiap.tcd6dvp.netflix.service.CacheService;
import com.fiap.tcd6dvp.netflix.redis.Cache;

@Component
public class MessageListener {
	int count = 0;
	
	@Autowired
    private CacheService cacheService;
	@Autowired
	private FilmeRepository filmeRepository;

	@RabbitListener(queues = MQConfig.QUEUE) //Alterar a fila de escuta para cada microserviço
    public void listener(CustomMessage message) {
		if (cacheService.fetchUserById(message.getMessage())!= null) {
			count = cacheService.fetchUserById(message.getMessage()).getVisto();
			count += 1;
		}else{
			count = 1;
		};
		Filme filme = filmeRepository.findById(message.getMessage());
		Cache cache = new Cache();
		cache.setId(message.getMessage());
		cache.setFilme(filme.getName());
		cache.setCategoria(filme.getCategoryName().getName());
		cache.setVisto(count);
		cacheService.saveUser(cache);
    }
}
